﻿using System;
using System.Windows.Forms;

namespace BST102_OtoSys_FinalProject
{
    public partial class Form2 : Form
    {
        public int AracId { get; set; }
        public string Marka { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int UretimAdedi { get; set; }
        public decimal Maliyet { get; set; }
        public decimal SatisTutari { get; set; }
        public bool SatildiMi { get; set; }

        public Form2(Arac secilen)
        {
            InitializeComponent();
            AracId = secilen.AracId;
            Marka = secilen.Marka;
            Model = secilen.Model;
            UretimAdedi = secilen.UretimAdedi;
            Maliyet = secilen.MaliyetTutari;
            SatisTutari = 0; // İsteğe bağlı alan, sistemde yoksa varsayılan bırakılır
            SatildiMi = secilen.SatisDurumu == 0;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            txtİD2.Text = AracId.ToString();
            txtMarka2.Text = Marka;
            txtModel2.Text = Model;
            numUretimAdedi2.Value = UretimAdedi;
            txtMaliyet2.Text = Maliyet.ToString();
            txtSatisTutari2.Text = SatisTutari.ToString();
            chkSatildimi2.Checked = SatildiMi;

            txtİD2.ReadOnly = true;
        }

        private void btnGuncelle2_Click(object sender, EventArgs e)
        {
            string yeniMarka = txtMarka2.Text;
            string yeniModel = txtModel2.Text;
            int yeniUretimAdedi = (int)numUretimAdedi2.Value;
            decimal yeniMaliyet = Convert.ToDecimal(txtMaliyet2.Text);
            decimal yeniSatisTutari = Convert.ToDecimal(txtSatisTutari2.Text);
            bool yeniSatildiMi = chkSatildimi2.Checked;

            if (this.Owner is Form1 mainForm)
            {
                mainForm.UpdateArac(AracId, yeniMarka, yeniModel, yeniUretimAdedi, yeniMaliyet, yeniSatisTutari, yeniSatildiMi);
                MessageBox.Show("Araç bilgileri başarıyla güncellendi.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Ana form bulunamadı.");
            }
        }

        private void btnIptal2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
